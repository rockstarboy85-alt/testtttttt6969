#!/bin/bash
# Anti-Theft Server Launcher Script

echo "============================================"
echo "   Anti-Theft Control Panel Server"
echo "============================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "[!] Python3 not found! Installing..."
    pkg install python -y
fi

# Check if required packages are installed
echo "[+] Checking dependencies..."
pip install -q flask flask-socketio eventlet

# Get IP address
echo ""
echo "[+] Your IP addresses:"
ip addr show | grep "inet " | awk '{print "    " $2}' | cut -d/ -f1
echo ""

# Start server
echo "[+] Starting server..."
echo "[+] Press Ctrl+C to stop"
echo "============================================"
echo ""

python3 server.py
