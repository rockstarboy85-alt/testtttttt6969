package com.antitheft.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.location.Location
import android.media.*
import android.os.*
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.Log
import android.view.Surface
nimport android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.android.gms.location.*
import io.socket.client.IO
import io.socket.client.Socket
import io.socket.emitter.Emitter
import org.json.JSONObject
import java.io.*
import java.net.URISyntaxException
import java.nio.ByteBuffer
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.concurrent.timerTask

class AntiTheftService : LifecycleService(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val NOTIFICATION_CHANNEL_ID = "AntiTheftChannel"
        const val NOTIFICATION_ID = 1
        
        @Volatile
        var isRunning = false
        
        private const val TAG = "AntiTheftService"
    }

    private lateinit var prefs: SharedPreferences
    private var socket: Socket? = null
    private var deviceId: String = ""
    private var serverUrl: String = ""
    private var deviceName: String = ""
    
    // Camera
    private var imageCapture: ImageCapture? = null
    private var cameraExecutor: ExecutorService? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var isLiveCamera = false
    private var autoCaptureTimer: Timer? = null
    
    // Audio
    private var audioRecorder: AudioRecord? = null
    private var isRecording = false
    private var isLiveMic = false
    private var micExecutor: ExecutorService? = null
    
    // TTS
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    
    // Flashlight
    private var cameraManager: CameraManager? = null
    private var cameraId: String? = null
    private var flashBlinkTimer: Timer? = null
    
    // Location
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    
    // Handler for main thread operations
    private lateinit var mainHandler: Handler

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("AntiTheftPrefs", Context.MODE_PRIVATE)
        cameraExecutor = Executors.newSingleThreadExecutor()
        micExecutor = Executors.newSingleThreadExecutor()
        mainHandler = Handler(Looper.getMainLooper())
        
        // Initialize TTS
        textToSpeech = TextToSpeech(this, this)
        
        // Initialize CameraManager for flashlight
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cameraId = cameraManager?.cameraIdList?.get(0)
        
        // Initialize Location
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        
        // Initialize CameraX
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        
        when (intent?.action) {
            ACTION_START -> startService()
            ACTION_STOP -> stopService()
        }
        
        return START_STICKY
    }

    private fun startService() {
        if (isRunning) return
        
        isRunning = true
        serverUrl = prefs.getString("server_url", "") ?: ""
        deviceName = prefs.getString("device_name", Build.MODEL) ?: Build.MODEL
        deviceId = prefs.getString("device_id", "") ?: ""
        
        if (deviceId.isEmpty()) {
            deviceId = UUID.randomUUID().toString()
            prefs.edit().putString("device_id", deviceId).apply()
        }

        createNotificationChannel()
        val notification = createNotification()
        startForeground(NOTIFICATION_ID, notification)

        connectSocket()
        
        Toast.makeText(this, "Anti-Theft Service Started", Toast.LENGTH_SHORT).show()
    }

    private fun stopService() {
        isRunning = false
        disconnectSocket()
        stopAutoCapture()
        stopLiveCamera()
        stopLiveMic()
        stopFlashBlink()
        stopRecording()
        
        cameraExecutor?.shutdown()
        micExecutor?.shutdown()
        
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        
        Toast.makeText(this, "Anti-Theft Service Stopped", Toast.LENGTH_SHORT).show()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Anti-Theft Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Anti-Theft device monitoring service"
                setShowBadge(true)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Anti-Theft Protection Active")
            .setContentText("Device is being monitored for security")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun connectSocket() {
        try {
            val options = IO.Options().apply {
                reconnection = true
                reconnectionAttempts = 10
                reconnectionDelay = 1000
                timeout = 10000
            }
            
            socket = IO.socket(serverUrl, options)
            
            socket?.on(Socket.EVENT_CONNECT, onConnect)
            socket?.on(Socket.EVENT_DISCONNECT, onDisconnect)
            socket?.on(Socket.EVENT_CONNECT_ERROR, onConnectError)
            socket?.on("command", onCommand)
            
            socket?.connect()
            
            Log.d(TAG, "Connecting to $serverUrl")
        } catch (e: URISyntaxException) {
            Log.e(TAG, "Invalid server URL: ${e.message}")
        }
    }

    private fun disconnectSocket() {
        socket?.off()
        socket?.disconnect()
        socket = null
    }

    private val onConnect = Emitter.Listener {
        Log.d(TAG, "Socket connected")
        
        val data = JSONObject().apply {
            put("device_id", deviceId)
            put("name", deviceName)
            put("model", Build.MODEL)
            put("manufacturer", Build.MANUFACTURER)
            put("android_version", Build.VERSION.RELEASE)
        }
        
        socket?.emit("register_device", data)
    }

    private val onDisconnect = Emitter.Listener {
        Log.d(TAG, "Socket disconnected")
    }

    private val onConnectError = Emitter.Listener { args ->
        Log.e(TAG, "Connection error: ${args.joinToString()}")
    }

    private val onCommand = Emitter.Listener { args ->
        try {
            val command = args[0] as JSONObject
            val cmdType = command.getString("type")
            val cmdData = command.optJSONObject("data")
            
            Log.d(TAG, "Received command: $cmdType")
            
            when (cmdType) {
                "take_photo" -> takePhoto(cmdData?.optString("camera", "back") ?: "back")
                "start_live_camera" -> startLiveCamera(cmdData?.optString("camera", "back") ?: "back")
                "stop_live_camera" -> stopLiveCamera()
                "start_auto_capture" -> startAutoCapture(
                    cmdData?.optInt("interval", 5) ?: 5,
                    cmdData?.optString("camera", "back") ?: "back"
                )
                "stop_auto_capture" -> stopAutoCapture()
                "record_audio" -> recordAudio(cmdData?.optInt("duration", 10) ?: 10)
                "start_live_mic" -> startLiveMic()
                "stop_live_mic" -> stopLiveMic()
                "tts" -> speakText(cmdData?.optString("text", "") ?: "")
                "play_audio" -> playAudio(cmdData?.optString("audio_data", "") ?: "")
                "get_location" -> getLocation()
                "flash_on" -> flashOn()
                "flash_off" -> flashOff()
                "flash_blink" -> flashBlink(cmdData?.optInt("speed", 500) ?: 500)
                "stop_flash_blink" -> stopFlashBlink()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing command: ${e.message}")
            e.printStackTrace()
        }
    }

    // ==================== CAMERA FUNCTIONS ====================

    private fun takePhoto(cameraType: String) {
        mainHandler.post {
            try {
                val cameraProvider = cameraProvider ?: return@post
                
                // Unbind all use cases
                cameraProvider.unbindAll()
                
                // Select camera
                val cameraSelector = if (cameraType == "front") {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }
                
                // Setup image capture
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                
                try {
                    cameraProvider.bindToLifecycle(
                        this,
                        cameraSelector,
                        imageCapture
                    )
                    
                    // Capture image
                    imageCapture?.takePicture(
                        ContextCompat.getMainExecutor(this),
                        object : ImageCapture.OnImageCapturedCallback() {
                            override fun onCaptureSuccess(image: ImageProxy) {
                                val buffer = image.planes[0].buffer
                                val bytes = ByteArray(buffer.remaining())
                                buffer.get(bytes)
                                
                                val base64Image = Base64.encodeToString(bytes, Base64.DEFAULT)
                                
                                sendResponse("photo", JSONObject().apply {
                                    put("camera", cameraType)
                                    put("image_data", "data:image/jpeg;base64,$base64Image")
                                    put("timestamp", System.currentTimeMillis())
                                })
                                
                                image.close()
                                
                                // Unbind after capture
                                cameraProvider.unbindAll()
                            }
                            
                            override fun onError(exception: ImageCaptureException) {
                                Log.e(TAG, "Photo capture failed: ${exception.message}")
                                sendResponse("error", JSONObject().apply {
                                    put("message", "Photo capture failed: ${exception.message}")
                                })
                            }
                        }
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Camera binding failed: ${e.message}")
                    sendResponse("error", JSONObject().apply {
                        put("message", "Camera binding failed: ${e.message}")
                    })
                }
            } catch (e: Exception) {
                Log.e(TAG, "Take photo error: ${e.message}")
            }
        }
    }

    private fun startLiveCamera(cameraType: String) {
        mainHandler.post {
            try {
                isLiveCamera = true
                val cameraProvider = cameraProvider ?: return@post
                
                cameraProvider.unbindAll()
                
                val cameraSelector = if (cameraType == "front") {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }
                
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                
                cameraProvider.bindToLifecycle(this, cameraSelector, imageCapture)
                
                // Start capturing frames
                Thread {
                    while (isLiveCamera) {
                        captureAndSendFrame(cameraType)
                        Thread.sleep(200) // 5 FPS
                    }
                }.start()
                
                sendResponse("live_camera_started", JSONObject().apply {
                    put("camera", cameraType)
                })
            } catch (e: Exception) {
                Log.e(TAG, "Start live camera error: ${e.message}")
            }
        }
    }

    private fun stopLiveCamera() {
        isLiveCamera = false
        cameraProvider?.unbindAll()
        sendResponse("live_camera_stopped", JSONObject())
    }

    private fun captureAndSendFrame(cameraType: String) {
        try {
            imageCapture?.takePicture(
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        try {
                            val buffer = image.planes[0].buffer
                            val bytes = ByteArray(buffer.remaining())
                            buffer.get(bytes)
                            
                            // Compress for streaming
                            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            val outputStream = ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, outputStream)
                            val compressedBytes = outputStream.toByteArray()
                            
                            val base64Image = Base64.encodeToString(compressedBytes, Base64.DEFAULT)
                            
                            sendResponse("live_frame", JSONObject().apply {
                                put("camera", cameraType)
                                put("image_data", "data:image/jpeg;base64,$base64Image")
                            })
                            
                            bitmap.recycle()
                        } catch (e: Exception) {
                            Log.e(TAG, "Frame processing error: ${e.message}")
                        }
                        image.close()
                    }
                    
                    override fun onError(exception: ImageCaptureException) {
                        Log.e(TAG, "Frame capture error: ${exception.message}")
                    }
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Capture frame error: ${e.message}")
        }
    }

    private fun startAutoCapture(interval: Int, cameraType: String) {
        stopAutoCapture()
        
        autoCaptureTimer = Timer()
        autoCaptureTimer?.scheduleAtFixedRate(timerTask {
            takePhoto(cameraType)
        }, 0, interval * 1000L)
        
        sendResponse("auto_capture_started", JSONObject().apply {
            put("interval", interval)
            put("camera", cameraType)
        })
    }

    private fun stopAutoCapture() {
        autoCaptureTimer?.cancel()
        autoCaptureTimer = null
        sendResponse("auto_capture_stopped", JSONObject())
    }

    // ==================== AUDIO FUNCTIONS ====================

    private fun recordAudio(duration: Int) {
        micExecutor?.execute {
            try {
                val sampleRate = 44100
                val channelConfig = AudioFormat.CHANNEL_IN_MONO
                val audioFormat = AudioFormat.ENCODING_PCM_16BIT
                val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
                
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
                    != PackageManager.PERMISSION_GRANTED) {
                    sendResponse("error", JSONObject().apply {
                        put("message", "Audio permission not granted")
                    })
                    return@execute
                }
                
                audioRecorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize
                )
                
                val audioData = ByteArrayOutputStream()
                val buffer = ByteArray(bufferSize)
                
                audioRecorder?.startRecording()
                isRecording = true
                
                val startTime = System.currentTimeMillis()
                while (isRecording && System.currentTimeMillis() - startTime < duration * 1000) {
                    val read = audioRecorder?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        audioData.write(buffer, 0, read)
                    }
                }
                
                audioRecorder?.stop()
                audioRecorder?.release()
                audioRecorder = null
                isRecording = false
                
                // Convert to WAV format
                val wavData = convertToWav(audioData.toByteArray(), sampleRate)
                val base64Audio = Base64.encodeToString(wavData, Base64.DEFAULT)
                
                sendResponse("audio", JSONObject().apply {
                    put("audio_data", "data:audio/wav;base64,$base64Audio")
                    put("duration", duration)
                    put("timestamp", System.currentTimeMillis())
                })
                
            } catch (e: Exception) {
                Log.e(TAG, "Record audio error: ${e.message}")
                sendResponse("error", JSONObject().apply {
                    put("message", "Audio recording failed: ${e.message}")
                })
            }
        }
    }

    private fun convertToWav(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val outputStream = ByteArrayOutputStream()
        val dataLength = pcmData.size
        val totalLength = dataLength + 36
        
        // WAV header
        outputStream.write("RIFF".toByteArray())
        outputStream.write(intToBytes(totalLength))
        outputStream.write("WAVE".toByteArray())
        outputStream.write("fmt ".toByteArray())
        outputStream.write(intToBytes(16)) // Subchunk1Size
        outputStream.write(shortToBytes(1)) // AudioFormat (PCM)
        outputStream.write(shortToBytes(1)) // NumChannels (Mono)
        outputStream.write(intToBytes(sampleRate))
        outputStream.write(intToBytes(sampleRate * 2)) // ByteRate
        outputStream.write(shortToBytes(2)) // BlockAlign
        outputStream.write(shortToBytes(16)) // BitsPerSample
        outputStream.write("data".toByteArray())
        outputStream.write(intToBytes(dataLength))
        outputStream.write(pcmData)
        
        return outputStream.toByteArray()
    }

    private fun intToBytes(value: Int): ByteArray {
        return byteArrayOf(
            (value and 0xFF).toByte(),
            ((value shr 8) and 0xFF).toByte(),
            ((value shr 16) and 0xFF).toByte(),
            ((value shr 24) and 0xFF).toByte()
        )
    }

    private fun shortToBytes(value: Short): ByteArray {
        return byteArrayOf(
            (value.toInt() and 0xFF).toByte(),
            ((value.toInt() shr 8) and 0xFF).toByte()
        )
    }

    private fun stopRecording() {
        isRecording = false
        audioRecorder?.stop()
        audioRecorder?.release()
        audioRecorder = null
    }

    private fun startLiveMic() {
        isLiveMic = true
        
        micExecutor?.execute {
            try {
                val sampleRate = 16000 // Lower for streaming
                val bufferSize = AudioRecord.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
                    != PackageManager.PERMISSION_GRANTED) {
                    return@execute
                }
                
                val recorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                
                recorder.startRecording()
                val buffer = ByteArray(bufferSize)
                
                while (isLiveMic) {
                    val read = recorder.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        val audioChunk = Base64.encodeToString(buffer.copyOf(read), Base64.DEFAULT)
                        sendResponse("live_audio_chunk", JSONObject().apply {
                            put("audio_data", audioChunk)
                        })
                    }
                    Thread.sleep(100)
                }
                
                recorder.stop()
                recorder.release()
                
            } catch (e: Exception) {
                Log.e(TAG, "Live mic error: ${e.message}")
            }
        }
        
        sendResponse("live_mic_started", JSONObject())
    }

    private fun stopLiveMic() {
        isLiveMic = false
        sendResponse("live_mic_stopped", JSONObject())
    }

    // ==================== TTS FUNCTIONS ====================

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            textToSpeech?.language = Locale.getDefault()
        }
    }

    private fun speakText(text: String) {
        if (ttsReady && text.isNotEmpty()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
            } else {
                @Suppress("DEPRECATION")
                textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null)
            }
            sendResponse("tts_complete", JSONObject().apply {
                put("text", text)
            })
        }
    }

    private fun playAudio(audioData: String) {
        try {
            if (audioData.isEmpty()) return
            
            val base64Data = audioData.replace("data:audio/wav;base64,", "")
                .replace("data:audio/mp3;base64,", "")
                .replace("data:audio/mpeg;base64,", "")
            
            val audioBytes = Base64.decode(base64Data, Base64.DEFAULT)
            
            val tempFile = File.createTempFile("audio", ".wav", cacheDir)
            FileOutputStream(tempFile).use { it.write(audioBytes) }
            
            val mediaPlayer = MediaPlayer()
            mediaPlayer.setDataSource(tempFile.absolutePath)
            mediaPlayer.prepare()
            mediaPlayer.start()
            
            mediaPlayer.setOnCompletionListener {
                it.release()
                tempFile.delete()
            }
            
            sendResponse("audio_playing", JSONObject())
        } catch (e: Exception) {
            Log.e(TAG, "Play audio error: ${e.message}")
            sendResponse("error", JSONObject().apply {
                put("message", "Audio playback failed: ${e.message}")
            })
        }
    }

    // ==================== LOCATION FUNCTIONS ====================

    private fun getLocation() {
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
                != PackageManager.PERMISSION_GRANTED) {
                sendResponse("error", JSONObject().apply {
                    put("message", "Location permission not granted")
                })
                return
            }
            
            val locationRequest = LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY,
                1000
            ).build()
            
            val locationCallback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    result.lastLocation?.let { location ->
                        sendResponse("location", JSONObject().apply {
                            put("latitude", location.latitude)
                            put("longitude", location.longitude)
                            put("accuracy", location.accuracy)
                            put("altitude", location.altitude)
                            put("speed", location.speed)
                            put("timestamp", location.time)
                        })
                        fusedLocationClient.removeLocationUpdates(this)
                    }
                }
            }
            
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
            
            // Fallback: get last known location
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                if (location != null) {
                    sendResponse("location", JSONObject().apply {
                        put("latitude", location.latitude)
                        put("longitude", location.longitude)
                        put("accuracy", location.accuracy)
                        put("altitude", location.altitude)
                        put("speed", location.speed)
                        put("timestamp", location.time)
                    })
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Get location error: ${e.message}")
            sendResponse("error", JSONObject().apply {
                put("message", "Location error: ${e.message}")
            })
        }
    }

    // ==================== FLASHLIGHT FUNCTIONS ====================

    private fun flashOn() {
        try {
            cameraId?.let { id ->
                cameraManager?.setTorchMode(id, true)
                sendResponse("flash_on", JSONObject())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Flash on error: ${e.message}")
        }
    }

    private fun flashOff() {
        try {
            cameraId?.let { id ->
                cameraManager?.setTorchMode(id, false)
                sendResponse("flash_off", JSONObject())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Flash off error: ${e.message}")
        }
    }

    private fun flashBlink(speed: Int) {
        stopFlashBlink()
        
        flashBlinkTimer = Timer()
        var isOn = false
        
        flashBlinkTimer?.scheduleAtFixedRate(timerTask {
            try {
                cameraId?.let { id ->
                    isOn = !isOn
                    cameraManager?.setTorchMode(id, isOn)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Flash blink error: ${e.message}")
            }
        }, 0, speed.toLong())
        
        sendResponse("flash_blinking", JSONObject().apply {
            put("speed", speed)
        })
    }

    private fun stopFlashBlink() {
        flashBlinkTimer?.cancel()
        flashBlinkTimer = null
        flashOff()
        sendResponse("flash_blink_stopped", JSONObject())
    }

    // ==================== HELPER FUNCTIONS ====================

    private fun sendResponse(type: String, data: JSONObject) {
        try {
            val response = JSONObject().apply {
                put("type", type)
                put("device_id", deviceId)
                put("data", data)
            }
            socket?.emit("device_response", response)
        } catch (e: Exception) {
            Log.e(TAG, "Send response error: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        stopService()
    }
}
