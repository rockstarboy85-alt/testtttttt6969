package com.antitheft.app

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.antitheft.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    
    private val PERMISSIONS_REQUEST_CODE = 100
    private val REQUIRED_PERMISSIONS = mutableListOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.INTERNET
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("AntiTheftPrefs", MODE_PRIVATE)

        // Load saved settings
        binding.etServerUrl.setText(prefs.getString("server_url", ""))
        binding.etDeviceName.setText(prefs.getString("device_name", Build.MODEL))

        // Check and request permissions
        checkPermissions()

        // Check battery optimization
        checkBatteryOptimization()

        // Update UI based on service status
        updateUI()

        // Connect button
        binding.btnConnect.setOnClickListener {
            if (validateInputs()) {
                saveSettings()
                startService()
            }
        }

        // Disconnect button
        binding.btnDisconnect.setOnClickListener {
            stopService()
        }

        // Check status button
        binding.btnCheckStatus.setOnClickListener {
            updateUI()
            Toast.makeText(this, "Status refreshed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkPermissions() {
        val permissionsToRequest = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsToRequest.toTypedArray(),
                PERMISSIONS_REQUEST_CODE
            )
        }
    }

    private fun checkBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }

    private fun validateInputs(): Boolean {
        val serverUrl = binding.etServerUrl.text.toString().trim()
        val deviceName = binding.etDeviceName.text.toString().trim()

        if (serverUrl.isEmpty()) {
            binding.etServerUrl.error = "Server URL required"
            return false
        }

        if (deviceName.isEmpty()) {
            binding.etDeviceName.error = "Device name required"
            return false
        }

        // Validate URL format
        if (!serverUrl.startsWith("http://") && !serverUrl.startsWith("https://")) {
            binding.etServerUrl.error = "URL must start with http:// or https://"
            return false
        }

        return true
    }

    private fun saveSettings() {
        prefs.edit().apply {
            putString("server_url", binding.etServerUrl.text.toString().trim())
            putString("device_name", binding.etDeviceName.text.toString().trim())
            apply()
        }
    }

    private fun startService() {
        val intent = Intent(this, AntiTheftService::class.java).apply {
            action = AntiTheftService.ACTION_START
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        
        Toast.makeText(this, "Anti-Theft Service Started", Toast.LENGTH_SHORT).show()
        updateUI()
    }

    private fun stopService() {
        val intent = Intent(this, AntiTheftService::class.java).apply {
            action = AntiTheftService.ACTION_STOP
        }
        startService(intent)
        Toast.makeText(this, "Anti-Theft Service Stopped", Toast.LENGTH_SHORT).show()
        updateUI()
    }

    private fun updateUI() {
        val isRunning = AntiTheftService.isRunning
        binding.tvStatus.text = if (isRunning) "Status: Connected" else "Status: Disconnected"
        binding.tvStatus.setTextColor(
            ContextCompat.getColor(
                this,
                if (isRunning) android.R.color.holo_green_dark else android.R.color.holo_red_dark
            )
        )
        binding.btnConnect.isEnabled = !isRunning
        binding.btnDisconnect.isEnabled = isRunning
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            val denied = permissions.zip(grantResults.toList())
                .filter { it.second != PackageManager.PERMISSION_GRANTED }
            
            if (denied.isNotEmpty()) {
                Toast.makeText(
                    this,
                    "Some permissions denied. App may not work properly.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }
}
