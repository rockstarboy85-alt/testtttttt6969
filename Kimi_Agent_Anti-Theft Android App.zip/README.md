# 🔒 Anti-Theft Android App System

A complete anti-theft solution with an Android client app and Python web-based control panel for monitoring and controlling your devices.

---

## 📁 Project Structure

```
AntiTheftApp/
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/antitheft/app/
│       │   ├── MainActivity.kt
│       │   ├── AntiTheftService.kt
│       │   └── BootReceiver.kt
│       └── res/
│           ├── layout/activity_main.xml
│           ├── drawable/
│           │   ├── bg_input.xml
│           │   └── ic_shield.xml
│           └── values/
│               ├── colors.xml
│               ├── strings.xml
│               └── themes.xml
├── build.gradle
├── settings.gradle
└── gradle.properties

AntiTheftServer/
└── server.py
```

---

## 🚀 Quick Start

### PART 1: Setup the Server (Controller Phone - Termux)

#### Step 1: Install Termux
Download Termux from F-Droid (recommended) or Play Store.

#### Step 2: Install Dependencies
```bash
# Update packages
pkg update && pkg upgrade -y

# Install Python
pkg install python -y

# Install required Python packages
pip install flask flask-socketio eventlet
```

#### Step 3: Run the Server
```bash
# Navigate to server directory
cd AntiTheftServer

# Run the server
python server.py
```

The server will start on port 5000. You'll see:
```
============================================================
   Anti-Theft Control Panel Server
============================================================

[+] Starting server...
[+] Access the control panel at:
    - Local:   http://localhost:5000
    - Network: http://0.0.0.0:5000
```

#### Step 4: Find Your Server IP
```bash
# Get your IP address
ifconfig
# or
ip addr show
```

Look for something like `192.168.1.XXX` - this is your server IP.

#### Step 5: Access Control Panel
Open a browser and go to:
- `http://localhost:5000` (on the same device)
- `http://192.168.1.XXX:5000` (from other devices on same network)

---

### PART 2: Build the Client App (Target Phones)

#### Option A: Build with Android Studio (Recommended)

1. **Install Android Studio**
   - Download from https://developer.android.com/studio

2. **Open Project**
   - Open the `AntiTheftApp` folder in Android Studio

3. **Sync Project**
   - Click "Sync Now" when prompted
   - Wait for Gradle sync to complete

4. **Build APK**
   - Go to `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - Or press `Ctrl+F9`

5. **Locate APK**
   - APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

#### Option B: Build with AIDE (Android IDE)

1. **Install AIDE**
   - Download AIDE from Play Store

2. **Create New Project**
   - Open AIDE
   - Create new Android project
   - Copy all files from `AntiTheftApp` to the project

3. **Build**
   - Click the "Run" button
   - APK will be generated automatically

#### Option C: Build with Termux (Advanced)

```bash
# Install required packages
pkg install openjdk-17 gradle -y

# Set JAVA_HOME
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk

# Navigate to project
cd AntiTheftApp

# Build APK
gradle assembleDebug

# APK location
# app/build/outputs/apk/debug/app-debug.apk
```

---

### PART 3: Install and Configure Client App

1. **Install APK**
   - Transfer `app-debug.apk` to target phone
   - Install the APK (allow "Unknown Sources" if prompted)

2. **Grant Permissions**
   - Open the app
   - Grant ALL requested permissions:
     - Camera
     - Microphone
     - Location
     - Notifications
     - Background location (if asked)

3. **Disable Battery Optimization**
   - Go to Settings → Apps → Anti-Theft Protection
   - Battery → Battery Optimization → Don't Optimize

4. **Configure Server**
   - Enter Server URL: `http://192.168.1.XXX:5000`
   - Enter Device Name (e.g., "Mom's Phone")
   - Click "CONNECT"

5. **Verify Connection**
   - Check the Web UI - your device should appear in the sidebar
   - Status should show "Online" with green dot

---

## 📱 Features

### Camera Control
- 📸 Take photo (front/back camera)
- 📡 Live camera streaming
- ⏱️ Auto capture with custom intervals

### Audio Control
- 🎙️ Record audio (10 seconds)
- 📡 Live microphone streaming
- 🔊 Text-to-Speech (make phone speak)
- ▶️ Play audio files remotely

### Flashlight Control
- 💡 Flashlight ON/OFF
- ✨ Blink mode with adjustable speed

### Location Tracking
- 📍 Get GPS coordinates
- 🗺️ Open in Google Maps
- Shows latitude, longitude, accuracy

### Photo Gallery
- 🖼️ View all captured photos
- 🔍 Full-screen view with zoom
- Organized by device

---

## 🔌 Connection Flow

```
┌─────────────────┐         ┌─────────────────┐         ┌─────────────────┐
│   Controller    │         │     Server      │         │  Target Phone   │
│    (Phone 1)    │◄───────►│   (Termux)      │◄───────►│  (Phone 2,3..)  │
│   Web Browser   │  HTTP   │   Port 5000     │ Socket  │   Client App    │
└─────────────────┘         └─────────────────┘         └─────────────────┘
```

1. Server starts on Phone 1 (Termux)
2. Client App connects from Phone 2, 3, etc.
3. Device appears in Web UI sidebar
4. User clicks commands in Web UI
5. Server forwards commands to device
6. Device executes and sends response back

---

## 🌐 Using with ngrok (Internet Access)

To control devices over the internet:

```bash
# Install ngrok
pkg install ngrok

# Set your authtoken (get from ngrok.com)
ngrok config add-authtoken YOUR_TOKEN

# Start tunnel to port 5000
ngrok http 5000
```

You'll get a public URL like `https://abc123.ngrok.io`
- Use this URL in the Client App
- Access control panel from anywhere

---

## ⚙️ Permissions Required

### Android App Permissions:
- `INTERNET` - Connect to server
- `CAMERA` - Take photos
- `RECORD_AUDIO` - Record audio
- `ACCESS_FINE_LOCATION` - GPS location
- `ACCESS_COARSE_LOCATION` - Network location
- `FOREGROUND_SERVICE` - Run in background
- `FOREGROUND_SERVICE_CAMERA` - Camera in background
- `FOREGROUND_SERVICE_MICROPHONE` - Mic in background
- `FOREGROUND_SERVICE_LOCATION` - Location in background
- `POST_NOTIFICATIONS` - Show notification
- `RECEIVE_BOOT_COMPLETED` - Auto-start on boot
- `FLASHLIGHT` - Control flashlight

---

## 🛠️ Troubleshooting

### App Not Connecting
1. Check server is running: `python server.py`
2. Verify IP address is correct
3. Ensure both devices are on same WiFi network
4. Check firewall settings

### Camera Not Working
1. Grant Camera permission in Settings
2. Close other apps using camera
3. Restart the app

### Location Not Working
1. Enable GPS/Location services
2. Grant Location permission
3. Go outside for better GPS signal

### Service Stops
1. Disable battery optimization
2. Enable "Auto-start" in phone settings
3. Lock app in recent apps

### "Permission Denied" Errors
- Go to Settings → Apps → Anti-Theft Protection → Permissions
- Enable ALL permissions manually

---

## 🔒 Security Notes

⚠️ **IMPORTANT:**
- This app is for **PERSONAL USE ONLY**
- Use only on **your own devices**
- The app shows a **visible notification** when active
- All permissions are **explicitly requested**
- Server runs on **your local network**

---

## 📋 System Requirements

### Server (Controller Phone):
- Android 7.0+ with Termux
- Python 3.8+
- 100MB free storage
- WiFi connection

### Client (Target Phones):
- Android 7.0+ (API 24+)
- Camera (front or back)
- GPS/Location services
- Microphone
- Flashlight (optional)

---

## 📝 File Descriptions

### Android Client Files:

| File | Purpose |
|------|---------|
| `MainActivity.kt` | Main UI, settings, permission handling |
| `AntiTheftService.kt` | Background service, Socket.IO, all commands |
| `BootReceiver.kt` | Auto-start service on boot |
| `activity_main.xml` | Main activity layout |
| `AndroidManifest.xml` | App configuration, permissions |
| `build.gradle` | Dependencies and build config |

### Python Server:

| File | Purpose |
|------|---------|
| `server.py` | Flask + SocketIO server with embedded web UI |

---

## 🔄 Updates & Maintenance

### To Update Client App:
1. Make code changes
2. Rebuild APK
3. Uninstall old version
4. Install new APK

### To Update Server:
1. Stop running server (Ctrl+C)
2. Edit server.py
3. Run `python server.py` again

---

## 💡 Tips

1. **Use Static IP**: Set static IP for server phone to avoid changing URL
2. **Port Forwarding**: Forward port 5000 on router for external access
3. **VPN**: Use VPN for secure remote access instead of ngrok
4. **Battery**: Keep server phone plugged in for 24/7 operation
5. **Backup**: Save device IDs for easy reconnection

---

## 📞 Support

For issues:
1. Check Troubleshooting section
2. Verify all permissions are granted
3. Check server logs in Termux
4. Restart both server and client

---

## 📄 License

This project is for educational and personal use only.

**Disclaimer**: The authors are not responsible for any misuse of this software. Use responsibly and legally.

---

## 🙏 Credits

- Socket.IO for real-time communication
- Flask for web framework
- CameraX for Android camera
- Google Play Services for location

---

**Made with ❤️ for device security and recovery**
