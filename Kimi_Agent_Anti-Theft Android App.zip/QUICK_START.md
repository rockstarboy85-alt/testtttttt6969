# 🚀 Anti-Theft System - Quick Start Guide

## Step 1: Start Server (Controller Phone)

```bash
# In Termux
cd AntiTheftServer
pip install flask flask-socketio eventlet
python server.py
```

**Server URL:** `http://YOUR_IP:5000`

---

## Step 2: Install Client App (Target Phone)

1. Install APK: `app-debug.apk`
2. Grant all permissions when prompted
3. Disable battery optimization

---

## Step 3: Connect Device

1. Open Anti-Theft app
2. Enter Server URL (e.g., `http://192.168.1.100:5000`)
3. Enter Device Name
4. Click **CONNECT**

---

## Step 4: Control from Web UI

Open browser on controller phone:
- `http://localhost:5000` or
- `http://YOUR_IP:5000`

---

## Common Commands

| Button | Action |
|--------|--------|
| 📸 Front/Back Photo | Take photo |
| ▶️ Live Front/Back | Start live camera |
| ⏹️ Stop | Stop live camera |
| 🎙️ Record 10s | Record audio |
| 📡 Live Mic | Stream microphone |
| 🔊 Speak | Text-to-speech |
| 💡 ON/OFF | Flashlight control |
| ✨ Blink | Flashlight blink |
| 📍 Get Location | GPS coordinates |

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Can't connect | Check IP, same WiFi |
| Camera error | Grant permission, close other apps |
| No location | Enable GPS, go outside |
| Service stops | Disable battery optimization |

---

## Find Your IP

```bash
# In Termux
ifconfig
# or
ip addr show wlan0
```

Look for: `inet 192.168.1.XXX`

---

**Done!** Your anti-theft system is ready! 🎉
